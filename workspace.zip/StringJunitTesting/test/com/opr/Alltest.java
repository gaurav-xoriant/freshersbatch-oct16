package com.opr;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({StringCharAtTest.class,StringConcatOprTest.class,StringGetLengthTest.class})
public class Alltest { 
}
