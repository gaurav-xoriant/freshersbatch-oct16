package com.lambda;
@FunctionalInterface
public interface Operation{
	int perform(int a,int b);
}
